const express = require('express');
const mongoose = require('mongoose');
const app = express();



mongoose.connect('mongodb://localhost:27017/myapp')
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.error(err));


const userSchema = new mongoose.Schema({
    username: String,
    password: String
});
const User = mongoose.model('User', userSchema);


app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.get('/', (req, res) => {
    res.render('login');
});

app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const user = await User.findOne({ username, password });
        if (user) {
            res.send('Login successful');
        } else {
            res.send('Invalid username or password');
        }
    } catch (err) {
        console.error(err);
        res.send('Error during login');
    }
});


app.listen(5000);
